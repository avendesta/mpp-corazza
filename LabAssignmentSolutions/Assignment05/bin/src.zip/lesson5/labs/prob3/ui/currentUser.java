package lesson5.labs.prob3.ui;

public interface currentUser {
	String getUsername();
	Boolean isLoggedIn();
}
