package lesson5.labs.prob2.behaviour;

public interface FlyBehaviour {
	public void fly();
}
