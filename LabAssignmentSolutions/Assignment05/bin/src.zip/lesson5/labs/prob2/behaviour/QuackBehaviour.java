package lesson5.labs.prob2.behaviour;

public interface QuackBehaviour {
	public void quack();
}
