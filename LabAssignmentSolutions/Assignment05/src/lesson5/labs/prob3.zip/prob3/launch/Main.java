package lesson5.labs.prob3.launch;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
