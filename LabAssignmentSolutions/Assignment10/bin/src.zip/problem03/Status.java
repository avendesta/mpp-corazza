package problem03;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
