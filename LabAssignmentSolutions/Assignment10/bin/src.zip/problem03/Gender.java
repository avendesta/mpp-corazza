package problem03;

public enum Gender {
	M, F
}
