package problem2;

public interface ClosedCurve {	
	double computePerimeter();
}
