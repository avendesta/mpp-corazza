package problem4.behaviour;

public interface FlyBehaviour extends Flyable {
	public void fly();
}
