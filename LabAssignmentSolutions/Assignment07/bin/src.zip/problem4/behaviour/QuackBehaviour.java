package problem4.behaviour;

public interface QuackBehaviour extends Quackable{
	public void quack();
}
