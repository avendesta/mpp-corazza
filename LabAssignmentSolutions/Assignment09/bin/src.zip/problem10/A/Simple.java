package problem10.A;

public class Simple {
	boolean flag;
	Simple(boolean f){
		flag = f;
	}

}
