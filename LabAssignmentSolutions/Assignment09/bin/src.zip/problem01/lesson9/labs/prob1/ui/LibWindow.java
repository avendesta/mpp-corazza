package problem01.lesson9.labs.prob1.ui;

public interface LibWindow {
	void init();
	boolean isInitialized();
	void isInitialized(boolean val);
	void setVisible(boolean b);
}

