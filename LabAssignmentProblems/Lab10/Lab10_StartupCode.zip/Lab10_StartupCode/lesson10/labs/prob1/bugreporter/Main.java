package lesson10.labs.prob1.bugreporter;

public class Main {

	public static void main(String[] args) {
		BugReportGenerator brg = new BugReportGenerator();
		brg.reportGenerator();

	}

}
