package lesson10.labs.prob3;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
